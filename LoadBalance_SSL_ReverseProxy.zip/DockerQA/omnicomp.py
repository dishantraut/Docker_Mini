from flask import Flask, render_template
import socket
app = Flask(__name__)


@app.route('/')
def index():
    return f"<H1>Yoo Man : Dishant : We-InfoTech ! : {socket.gethostname()}</H1>"
