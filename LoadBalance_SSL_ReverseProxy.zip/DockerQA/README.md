
# Standard Instuctions For All
Backup Files To Be Renamed = fileName.extension_DDMMMYYY (eg :- Filename.py_10Jan1997)
Backup Files To Be Moved To = BackUpFiles
Test Code To Be Written In = developerName.py (eg :- vishal.sh)

# Start / Stop Server
sh ./Scripts/stop.sh
sh ./Scripts/stop.sh

# Liquidation / Compensation Run Commands
** Retailer Job - Dump Retailers To Database
sh ./Scripts/retailer_loader.sh > ./LogFiles/loader_jobs.log 2>&1

** Phase 1 Job - File Upload + Validations + P1 Report Generation + Commission Calculations
python3 base_liquidation.py CombineProcessingPhaseOne today> ./LogFiles/PhaseOne_jobs.log 2>&1

** Phase 2 Job - Report Generation / CCX24 / ZIP_FTP
sh ./Scripts/phase_two.sh

# Check Port Status [ In Case Of Env Down ]
lsof -i:6060

# Check Status Log [ In Case Of Env Down ]
tail -n 50 gunicorn.log

# Docker Compose Commands
docker-compose -f docker-compose-qa.yml up -d --scale compsan_qa=5
docker-compose -f docker-compose-qa.yml ps
docker-compose -f docker-compose-qa.yml down

# Docker Commands
docker network ls; echo -e "\n\n" ;docker volume ls
clear; docker images | grep "adminer\|mysql\|ankita"; echo -e "\n\n"; docker ps | grep qa
